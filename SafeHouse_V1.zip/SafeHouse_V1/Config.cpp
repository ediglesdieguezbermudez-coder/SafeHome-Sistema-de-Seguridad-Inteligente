/*****************************************************************
 *  SafeHouse v1.0
 *---------------------------------------------------------------
 *  Archivo : Config.cpp
 *  Hardware: ESP8266 NodeMCU
 *  IDE      : Arduino IDE 2.3.10
 *---------------------------------------------------------------
 *  Implementación de la configuración general
 *****************************************************************/

#include "Config.h"

/*************************************************************
    Variable global del sistema
*************************************************************/

SystemStatus systemStatus =
{
    DISARMED,      // Estado inicial

    false,         // PIR1
    false,         // PIR2

    false,         // Sirena

    false,         // Buzzer

    false,         // WiFi

    0,             // Contador movimientos

    0              // Contador disparos
};

/*************************************************************
    Conectar a la red WiFi
*************************************************************/

void connectWiFi()
{
    Serial.println();
    Serial.println("====================================");
    Serial.println("Conectando a la red WiFi");
    Serial.println("====================================");

    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    uint8_t intentos = 0;

    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);

        Serial.print(".");

        intentos++;

        if (intentos >= 60)
        {
            Serial.println();
            Serial.println("No fue posible conectar al WiFi.");

            systemStatus.wifiConnected = false;

            return;
        }
    }

    systemStatus.wifiConnected = true;

    Serial.println();
    Serial.println("------------------------------------");
    Serial.println("WiFi conectado");
    Serial.print("SSID : ");
    Serial.println(WIFI_SSID);

    Serial.print("IP   : ");
    Serial.println(WiFi.localIP());

    Serial.print("RSSI : ");
    Serial.print(WiFi.RSSI());
    Serial.println(" dBm");

    Serial.println("------------------------------------");
}

/*************************************************************
    Obtener dirección IP
*************************************************************/

String getIPAddress()
{
    if (WiFi.status() == WL_CONNECTED)
    {
        return WiFi.localIP().toString();
    }

    return String("0.0.0.0");
}

/*************************************************************
    Convertir estado de la alarma a texto
*************************************************************/

String getStateString()
{
    switch (systemStatus.state)
    {
        case DISARMED:
            return "DESARMADO";

        case EXIT_DELAY_STATE:
            return "RETARDO_SALIDA";

        case ARMED:
            return "ARMADO";

        case ENTRY_DELAY_STATE:
            return "RETARDO_ENTRADA";

        case ALARM_TRIGGERED:
            return "ALARMA";

        case NIGHT_MODE:
            return "VIGILIA";

        default:
            return "DESCONOCIDO";
    }
}