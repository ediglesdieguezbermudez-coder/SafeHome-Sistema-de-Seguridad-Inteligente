/*****************************************************************
 *
 *  SafeHouse v1.0
 *---------------------------------------------------------------
 *  Archivo : WebServer.cpp
 *---------------------------------------------------------------
 *  ETAPA 1
 *
 *****************************************************************/

#include "WebServer.h"

ESP8266WebServer server(HTTP_PORT);
WebSocketsServer webSocket(81);/*Etapa 2*/
/*************************************************************
    Iniciar servidor
*************************************************************/

void startWebServer()
{

    Serial.println();
    Serial.println("--------------------------------");
    Serial.println("Inicializando Servidor Web");
    Serial.println("--------------------------------");

    /******************************************************
        Rutas principales
    ******************************************************/

    server.on("/", HTTP_GET, handleRoot);

    server.on("/status", HTTP_GET, handleStatus);

    /******************************************************
        Comandos (Etapa 3)
    ******************************************************/

    server.on("/arm", HTTP_GET, []()
    {
        server.send(200,"text/plain","OK");
    });

    server.on("/disarm", HTTP_GET, []()
    {
        server.send(200,"text/plain","OK");
    });

    server.on("/night", HTTP_GET, []()
    {
        server.send(200,"text/plain","OK");
    });

    server.on("/panic", HTTP_GET, []()
    {
        server.send(200,"text/plain","OK");
    });

    server.on("/silence", HTTP_GET, []()
    {
        server.send(200,"text/plain","OK");
    });

    server.on("/restart", HTTP_GET, []()
    {
        server.send(200,"text/plain","OK");
    });

    /******************************************************
        Archivos estáticos
    ******************************************************/

    server.on("/style.css", HTTP_GET, []()
    {
        handleFileRead("/style.css");
    });

    server.on("/script.js", HTTP_GET, []()
    {
        handleFileRead("/script.js");
    });

    /******************************************************
        Error 404
    ******************************************************/

    server.onNotFound(handleNotFound);

    server.begin();

    initWebSocket();/*Etapa 2*/

    Serial.println("Servidor HTTP iniciado");

    Serial.print("Puerto : ");

    Serial.println(HTTP_PORT);

}

/*************************************************************
    Atención servidor
*************************************************************/

void handleWebServer()
{
    server.handleClient();

    webSocket.loop();/*Etapa 2*/

}
/*Etapa 2*/
void initWebSocket()
{
    webSocket.begin();

    webSocket.onEvent(onWebSocketEvent);

    Serial.println("WebSocket iniciado");
}

void onWebSocketEvent(
    uint8_t client,
    WStype_t type,
    uint8_t *payload,
    size_t length)
{
    switch(type)
    {

        case WStype_CONNECTED:
        {
            Serial.printf("Cliente %u conectado\n", client);

            String json = createStatusJSON();

            webSocket.sendTXT(client, json);

            break;
        }

        case WStype_DISCONNECTED:
        {
            Serial.printf("Cliente %u desconectado\n", client);

            break;
        }

        case WStype_TEXT:
        {
            Serial.printf("Mensaje recibido: %s\n", payload);

            break;
        }

        default:
        {
            break;
        }
    }
}

void broadcastStatus()
{
    String json = createStatusJSON();
    webSocket.broadcastTXT(json);
}

/*************************************************************
    Página principal
*************************************************************/

void handleRoot()
{

    if(!handleFileRead("/index.html"))
    {
        server.send(
            404,
            "text/plain",
            "index.html no encontrado"
        );
    }

}

/*************************************************************
    Estado del sistema (JSON)
*************************************************************/

void handleStatus()
{
    server.send(
        200,
        "application/json",
        createStatusJSON()
    );
}

/*************************************************************
    Crear JSON de estado
*************************************************************/

String createStatusJSON()
{
    String json = "{";

    json += "\"state\":\"" + getStateString() + "\",";
    json += "\"detail\":\"Sistema operativo\",";
    json += "\"timer\":\"\",";

    json += "\"pir1\":";
    json += systemStatus.pir1 ? "true," : "false,";

    json += "\"pir2\":";
    json += systemStatus.pir2 ? "true," : "false,";

    json += "\"movements\":";
    json += String(systemStatus.movementCounter);
    json += ",";

    json += "\"triggers\":";
    json += String(systemStatus.triggerCounter);
    json += ",";

    json += "\"wifi\":";
    json += systemStatus.wifiConnected ? "true," : "false,";

    json += "\"ip\":\"";
    json += getIPAddress();
    json += "\"";

    json += "}";

    return json;
}

/*************************************************************
    Tipo MIME
*************************************************************/

String getContentType(const String &filename)
{

    if (filename.endsWith(".html"))
        return "text/html";

    if (filename.endsWith(".css"))
        return "text/css";

    if (filename.endsWith(".js"))
        return "application/javascript";

    if (filename.endsWith(".json"))
        return "application/json";

    if (filename.endsWith(".png"))
        return "image/png";

    if (filename.endsWith(".gif"))
        return "image/gif";

    if (filename.endsWith(".jpg"))
        return "image/jpeg";

    if (filename.endsWith(".jpeg"))
        return "image/jpeg";

    if (filename.endsWith(".ico"))
        return "image/x-icon";

    if (filename.endsWith(".svg"))
        return "image/svg+xml";

    if (filename.endsWith(".txt"))
        return "text/plain";

    if (filename.endsWith(".pdf"))
        return "application/pdf";

    return "application/octet-stream";
}
/*************************************************************
    Leer archivo desde LittleFS
*************************************************************/

bool handleFileRead(const String &path)
{
    String filePath = path;

    // Si solicitan un directorio, entregar index.html
    if (filePath.endsWith("/"))
    {
        filePath += "index.html";
    }

    if (!LittleFS.exists(filePath))
    {
        return false;
    }

    File file = LittleFS.open(filePath, "r");

    if (!file)
    {
        return false;
    }

    String contentType = getContentType(filePath);

    server.streamFile(file, contentType);

    file.close();

    return true;
}

/*************************************************************
    Página no encontrada (404)
*************************************************************/

void handleNotFound()
{
    // Intentar servir el archivo solicitado desde LittleFS
    if (handleFileRead(server.uri()))
    {
        return;
    }

    String message;

    message += "404 - Recurso no encontrado\n\n";

    message += "URI: ";
    message += server.uri();
    message += "\n";

    message += "Metodo: ";
    message += (server.method() == HTTP_GET) ? "GET" : "POST";
    message += "\n";

    message += "Argumentos: ";
    message += String(server.args());
    message += "\n";

    for (uint8_t i = 0; i < server.args(); i++)
    {
        message += "  ";
        message += server.argName(i);
        message += " = ";
        message += server.arg(i);
        message += "\n";
    }

    server.send(
        404,
        "text/plain",
        message
    );
}

/*************************************************************
    Fin del archivo
*************************************************************/