/*****************************************************************
 *  SafeHouse v1.0
 *---------------------------------------------------------------
 *  Archivo : Pins.h
 *  Hardware: ESP8266 NodeMCU
 *---------------------------------------------------------------
 *  Definición de pines del sistema
 *****************************************************************/

#ifndef PINS_H
#define PINS_H

#include <Arduino.h>

/*************************************************************
    Entradas
*************************************************************/

// Sensores PIR

#define PIN_PIR1          D5      // GPIO14
#define PIN_PIR2          D6      // GPIO12

// Pulsador de armado/desarmado local

#define PIN_BUTTON        D3      // GPIO0

/*************************************************************
    Salidas
*************************************************************/

// Sirena

#define PIN_SIREN         D1      // GPIO5

// Buzzer

#define PIN_BUZZER        D2      // GPIO4

// LED Estado Armado

#define PIN_LED_ARMED     D7      // GPIO13

// LED Estado Desarmado

#define PIN_LED_READY     D0      // GPIO16

/*************************************************************
    Funciones
*************************************************************/

inline void initializePins()
{
    // Entradas

    pinMode(PIN_PIR1, INPUT);
    pinMode(PIN_PIR2, INPUT);

    pinMode(PIN_BUTTON, INPUT_PULLUP);

    // Salidas

    pinMode(PIN_SIREN, OUTPUT);
    pinMode(PIN_BUZZER, OUTPUT);
    pinMode(PIN_LED_ARMED, OUTPUT);
    pinMode(PIN_LED_READY, OUTPUT);

    // Estados iniciales

    digitalWrite(PIN_SIREN, LOW);
    digitalWrite(PIN_BUZZER, LOW);

    digitalWrite(PIN_LED_ARMED, LOW);
    digitalWrite(PIN_LED_READY, HIGH);
}

#endif