/*****************************************************************
 *  SafeHouse v1.0
 *---------------------------------------------------------------
 *  Archivo : SafeHouse.ino
 *  Hardware: ESP8266 NodeMCU
 *  IDE      : Arduino IDE 2.3.10
 *
 *  ETAPA 1
 *      - WiFi
 *      - LittleFS
 *      - Servidor Web
 *
 *****************************************************************/

#include <Arduino.h>
#include <LittleFS.h>

#include "Pins.h"
#include "Config.h"
#include "WebServer.h"

/*************************************************************
    Variables
*************************************************************/

unsigned long previousStatus = 0;
const unsigned long STATUS_PERIOD = 5000;

/*************************************************************
    SETUP
*************************************************************/

void setup()
{
    Serial.begin(115200);

    Serial.println();
    Serial.println("======================================");
    Serial.println("      SAFEHOUSE v1.0");
    Serial.println("======================================");

    initializePins();

    Serial.println();
    Serial.println("Inicializando LittleFS...");

    if (!LittleFS.begin())
    {
        Serial.println("ERROR montando LittleFS");

        while (true)
        {
            yield();
        }
    }

    Serial.println("LittleFS OK");

    connectWiFi();

    //startWebServer();
    if(systemStatus.wifiConnected)
    {
        startWebServer();
        }

    Serial.println();
    Serial.println("Sistema iniciado correctamente");
    Serial.println();
}

/*************************************************************
    LOOP
*************************************************************/

void loop()
{
    handleWebServer();

    unsigned long currentMillis = millis();

    if (currentMillis - previousStatus >= STATUS_PERIOD)
    {
        previousStatus = currentMillis;

        systemStatus.wifiConnected =
            (WiFi.status() == WL_CONNECTED);

        Serial.println("--------------------------------");

        Serial.print("Estado : ");
        Serial.println(getStateString());

        Serial.print("IP      : ");
        Serial.println(getIPAddress());

        Serial.print("WiFi    : ");

        if (systemStatus.wifiConnected)
            Serial.println("Conectado");
        else
            Serial.println("Desconectado");

        Serial.println("--------------------------------");
    }
}