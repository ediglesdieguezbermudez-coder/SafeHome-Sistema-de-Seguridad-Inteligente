/*****************************************************************
 *  SafeHouse v1.0
 *---------------------------------------------------------------
 *  Archivo : Config.h
 *  Hardware: ESP8266 NodeMCU
 *  IDE      : Arduino IDE 2.3.10
 *---------------------------------------------------------------
 *  Configuración general del sistema
 *****************************************************************/

#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>
#include <ESP8266WiFi.h>

/*************************************************************
    DATOS WIFI
    (Modificar según la red del usuario)
*************************************************************/

#define WIFI_SSID       "Mi"
#define WIFI_PASSWORD   "B1d01**e92"

/*************************************************************
    INFORMACIÓN DEL SISTEMA
*************************************************************/

#define DEVICE_NAME     "SafeHouse"
#define VERSION         "1.0"

/*************************************************************
    PUERTO DEL SERVIDOR WEB
*************************************************************/

#define HTTP_PORT       80

/*************************************************************
    TIEMPOS (milisegundos)
*************************************************************/

// Retardo de salida

const uint32_t EXIT_DELAY = 30000;

// Retardo de entrada

const uint32_t ENTRY_DELAY = 20000;

// Tiempo máximo de sirena

const uint32_t SIREN_TIME = 180000;

// Autoarmado

const uint32_t AUTO_ARM_TIME = 300000;

/*************************************************************
    ESTADOS DE LA ALARMA
*************************************************************/

enum AlarmState
{
    DISARMED = 0,
    EXIT_DELAY_STATE,
    ARMED,
    ENTRY_DELAY_STATE,
    ALARM_TRIGGERED,
    NIGHT_MODE
};

/*************************************************************
    ESTRUCTURA GENERAL DEL SISTEMA
*************************************************************/

struct SystemStatus
{
    AlarmState state;

    bool pir1;
    bool pir2;

    bool siren;

    bool buzzer;

    bool wifiConnected;

    uint32_t movementCounter;

    uint32_t triggerCounter;
};

/*************************************************************
    VARIABLES GLOBALES
*************************************************************/

extern SystemStatus systemStatus;

/*************************************************************
    FUNCIONES
*************************************************************/

void connectWiFi();

String getIPAddress();

String getStateString();

#endif