/*****************************************************************
 *  SafeHouse v1.0
 *---------------------------------------------------------------
 *  Archivo : WebServer.h
 *  Hardware: ESP8266 NodeMCU
 *  IDE      : Arduino IDE 2.3.10
 *
 *  Módulo Servidor Web
 *****************************************************************/

#ifndef WEBSERVER_H
#define WEBSERVER_H

#include <Arduino.h>
#include <ESP8266WebServer.h>
#include <WebSocketsServer.h>
#include <LittleFS.h>

#include "Config.h"

/*************************************************************
    Objeto servidor HTTP
*************************************************************/

extern ESP8266WebServer server;

/*************************************************************
    Inicialización
*************************************************************/

void startWebServer();
void handleWebServer();

/*************************************************************
    Rutas HTTP
*************************************************************/

void handleRoot();
void handleStatus();
void handleNotFound();
void initWebSocket();
/*Nuevas funsiones de la etapa 2******************************/
void handleWebSocket();

void broadcastStatus();

void onWebSocketEvent(
    uint8_t client,
    WStype_t type,
    uint8_t * payload,
    size_t length
);
extern WebSocketsServer webSocket;
/************************************************************/

/*************************************************************
    Archivos estáticos
*************************************************************/

bool handleFileRead(const String &path);

String getContentType(const String &filename);

/*************************************************************
    Utilidades
*************************************************************/

String createStatusJSON();

#endif